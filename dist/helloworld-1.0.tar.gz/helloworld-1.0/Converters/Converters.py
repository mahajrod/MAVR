#!/usr/bin/env python2


def fastq2fasta(input_file, output_file):
    input_fd = open(input_file, "r")
    output_fd = open(output_file, "w")

    for line in input_fd:
        if line[0] == "@":
            output_fd.write(">" + line[1:])
            i = 0
            for line in input_fd:
                if line[0] == "+":
                    break
                i += 1
                output_fd.write(line)
            i -= 1
            for line in input_fd:
                if i == 0:
                    break
                i -= 1

    input_fd.close()
    output_fd.close()