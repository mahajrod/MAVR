#!/usr/bin/env python2

from Bio import SeqIO
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord

from Mutation import *


class SeqDict(object):
	"""docstring for SeqDict"""
	allowed_filetypes  = 	[				\
							"genbank",		\
							"fasta",		\
							]
	dictionary = {}
	align_tool_bin = {		\
					 "Clustalw": ""	,	\
					 "TCoffee":	""		\
					 }
	def __init__(self, verbose = False):
		"""Description of the arguments:
			1) files_dict  - dictionary with sourse files, sorted by type
				ex: {
					"fasta" 	: [<list of fasta files>],
					"genbank"	: [<list of genbank files>]	
					}
			2) possible dict_type values:
					to_dict			all data in memory
					index  			only index in memory
					index_db 		creates index file on disk
		"""
		super(SeqDict, self).__init__()
		self.verbose = verbose
		
	def make_dict_from_files(self, files_dict, dict_type = "to_dict"):
		for ftype in files_dict:
			if ftype in self.allowed_filetypes:
				self.dictionary[ftype] = {}			
				if dict_type == "to_dict":
					for seqfile in files_dict[ftype]:
						self.dictionary[ftype].update(SeqIO.to_dict(SeqIO.parse(seqfile,ftype)))
					if self.verbose:
						print ("\tSource files were parsed. Sequence records were stored in memory")
				elif dict_type == "index":
					for seqfile in files_dict[ftype]:
						self.dictionary[ftype].update(SeqIO.index(seqfile,ftype))
					if self.verbose:
						print ("\tSource files were parsed. Index of source files was stored in memory"	)
				elif dict_type == "index_db":
					self.dictionary[ftype]=SeqIO.index_db(ftype +".idx",files_dict[ftype],ftype) 
					if self.verbose:
						print ("\tSource files were parsed. Index of source files was stored as file on disk"	)
				else:
					assert False , "Error 4: Unrecognized type of the SeqDict"
				
	def dict_info(self):
		pass

	def seq_info(self):
		pass			

	def align(self, alignment_tool = "TCoffee"):
		pass

	def save_align(self, filename):
		pass

	def find_mutations(self, ref_seq):
		pass

class NucleotideDict(SeqDict):
	"""docstring for NucleotideDict"""
	def __init__(self, arg):
		super(NucleotideDict, self).__init__()
		self.arg = arg
	
	def structure(self):
		pass	

	def structure_element(self, element_type, element_number):
		pass

	def structure_element_by_length(self):
		pass	

	def mRNA(self):
		pass

	def mRNA_alt_spliced(self, retained_intron_list):
		pass

	def CDS(self):
		pass	

	def rev_complement(self):
		pass

	def complement(self):
		pass

	def reverse(self):
		pass

	def translate(self):
		pass

class ProteinDict(SeqDict):
	"""docstring for ProteinDict"""
	def __init__(self, arg):
		super(ProteinDict, self).__init__()
		self.arg = arg

	def structure(self):
		pass	
		
